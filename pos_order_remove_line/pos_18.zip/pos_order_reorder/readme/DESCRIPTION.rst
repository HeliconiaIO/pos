This module allows you to re-order a paid order on a new order:
  .. image:: ../static/img/reorder_button.png
