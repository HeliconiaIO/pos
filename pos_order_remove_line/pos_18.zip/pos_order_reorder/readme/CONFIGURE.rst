Select PoS > Configuration > Settings > enable flag "Allow Reorder"
