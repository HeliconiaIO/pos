* Open the Point of sale

* Select a product

* Click on 'New line'

.. figure:: ../static/description/new_line_button.png

* Select again the same product

* A new line will be created.
