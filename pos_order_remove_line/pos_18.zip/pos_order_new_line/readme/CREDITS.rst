The development of this module has been financially supported by:

* UGESS, Union Nationale des Groupements des épiceries Sociales et Solidaires (https://ugess.org/)
