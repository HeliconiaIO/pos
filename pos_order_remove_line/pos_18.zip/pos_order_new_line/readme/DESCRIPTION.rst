This module extends the functionality of point of sale module, to allow to force
Point of sale to create a new order line, when selecting a product previously selected.

That can be usefull, if you want to sale the same product with different prices
and or discount. For exemple :

- You sell carrots, and some carrots are quite old, and you want to
  apply discount to a part of the products. (but not all the product)

- You want to manually apply some discount like :
  "2 Coca cola sold, the third will have a 10% discount".
