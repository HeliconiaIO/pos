* Go to "Point of Sale > Product" and edit a product

* Uncheck the checkbox "Mergeable line"

.. figure:: ../static/description/product_form.png