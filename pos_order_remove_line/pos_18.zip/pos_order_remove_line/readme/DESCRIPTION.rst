The module adds the possibility to delete a POS Order Line from the POS interface.
